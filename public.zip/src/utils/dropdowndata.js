export const mascotaOptions = [
  {
    name:'Mascotas',
    bathname:'/pets',
  },
  {
    name:'Busqueda',
    bathname:'/search',
  },
  {
    name:'Raza',
    bathname:'/raza',
  },
  {
    name:'Convenios',
    bathname:'/agreemetns',
  },
  {
    name:'DNI',
    bathname:'/dni',
  },
  // {
    // name:'Solicitudes y Servicios',
    // bathname:'/req_serv',
  // },
  {
    name:'Envato',
    bathname:'/envato',
  },
  {
    name:'Beneficios',
    bathname:'/benifits',
  },
];

// export const mascotaOptions = [
//   "Mascotas",
//   "Busqueda",
//   "Raza",
//   "Convenios",
//   "DNI",
//   "Solicitudes y Servicios",
//   "Evento",
//   "Beneficios",
// ];

export const userOptions = ["Usuarios"];
