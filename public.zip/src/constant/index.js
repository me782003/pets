export const base_url = "https://camp-coding.site/pets/api/admins/";
export const img_base_url = "https://camp-coding.site/pets/api/";
export const globa_base_url = "https://camp-coding.site/pets/api/";
