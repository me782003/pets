import './style.css';
export default function Footer() {
  return (
    <div className="footer">
        <p className='text-center fs-6'>Copyright © World Pets Perú 2024</p>
    </div>
  )
}
